print(string.format("%-40s gametag -- %s", gameinfo.getromhash(), gameinfo.getromname()))
